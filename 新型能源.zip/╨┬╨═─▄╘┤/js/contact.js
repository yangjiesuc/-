$(function(){
    $('.ft ').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ftt-1 span').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
    $('.lx').scrollspy({
        animation: 'slide-left',
        delay: 500,
        repeat: false
    })
    $('.join').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
})