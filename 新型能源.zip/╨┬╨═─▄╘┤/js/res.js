$(function(){
    $('.ft ').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ftt-1 span').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
    $('.energy').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.energy-1').scrollspy({
        animation: 'slide-bottom',
        delay: 700,
        repeat: false
    })
    $('.news-2 ').scrollspy({
        animation: 'slide-right',
        delay: 700,
        repeat: false
    })
    
})