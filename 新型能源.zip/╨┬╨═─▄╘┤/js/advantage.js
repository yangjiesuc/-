$(function(){
    $('.ad').scrollspy({
        animation: 'slide-bottom',
        delay: 300,
        repeat: false
    })
    $('.ad-1 img').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ad-1 h1').scrollspy({
        animation: 'slide-right',
        delay: 400,
        repeat: false
    })
    $('.ad-1 span').scrollspy({
        animation: 'slide-right',
        delay: 400,
        repeat: false
    })
    $('.ad-2 ').scrollspy({
        animation: 'slide-right',
        delay: 400,
        repeat: false
    })
    $('.tr-1 ').scrollspy({
        animation: 'slide-bottom',
        delay: 400,
        repeat: false
    })
    $('.ft ').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ftt-1 span').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
    $('.pt').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
})