$(function() {
    var mySwiper = new Swiper('.swiper-container', {
        autoplay: 2000, //可选选项，自动滑动
        pagination: '.swiper-pagination',
        paginationType: 'bullets',
        paginationClickable: true,
        effect: 'cube',
        autoplayDisableOnInteraction: false,
        autoplayStopOnLast: false,
        loop: true,
    })
    $('.bt').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.xny').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.bt-1 div').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.bt-2 div').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.bt-3 div').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.btt img').scrollspy({
        animation: 'slide-bottom',
        delay: 300,
        repeat: false
    })
    $('.ad').scrollspy({
        animation: 'slide-bottom',
        delay: 300,
        repeat: false
    })
    $('.ad-1 img').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ad-1 div').scrollspy({
        animation: 'slide-right',
        delay: 400,
        repeat: false
    })
    $('.ad-2 ').scrollspy({
        animation: 'slide-right',
        delay: 400,
        repeat: false
    })
    $('.tr-1 ').scrollspy({
        animation: 'slide-bottom',
        delay: 400,
        repeat: false
    })
    $('.ftt-1 span').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
    $('.ft ').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
})