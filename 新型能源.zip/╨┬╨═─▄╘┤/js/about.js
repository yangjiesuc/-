$(function(){
    $('.gs-1').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.gss-1 h1').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.gss-1 p').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat:false
    })
    $('.gss-2').scrollspy({
        animation: 'slide-left',
        delay: 500,
        repeat: false
    })
    $('.gss-3').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat:false
    })
    $('.ry').scrollspy({
        animation: 'slide-bottom',
        delay: 700,
        repeat: false
    })
    $('.ry-1 img').scrollspy({
        animation: 'slide-bottom',
        delay: 500,
        repeat: false
    })
    $('.ft ').scrollspy({
        animation: 'slide-right',
        delay: 300,
        repeat: false
    })
    $('.ftt-1 span').scrollspy({
        animation: 'slide-right',
        delay: 500,
        repeat: false
    })
})